class Tester
{
public static void main(String[] args)
{
Point2D p1=new Point2D(5.6,7.5);
Point2D p2=p1;
boolean s=p1.isEqual(p2);
System.out.println(s);

if(s==true)
{
System.out.println("Both are Same");
}
else
{
System.out.println("Different");
}

}
}