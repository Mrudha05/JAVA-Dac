class Point2D
{
private double x;
private double y;
public Point2D(double x,double y)
{
	this.x=x;
	this.y=y;
}
public String Show()
{
return "Co-ordinates of x and y are "+this.x+" "+this.y;
}
public Boolean isEqual(Point2D p)
{
 if(this.x==p.x && this.y==p.y)
{
return true;
}
else
{ return false;}


}
}