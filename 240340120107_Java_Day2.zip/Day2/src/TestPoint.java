import java.util.Scanner;
class TestPoint
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the x and y coordinates");
Point2D p;
p=new Point2D(sc.nextDouble(),sc.nextDouble());
System.out.println(p);
System.out.println(p.Show());
}
}

