package utils;

import java.time.LocalDate;
import java.util.List;
import java.util.regex.Pattern;

import com.app.customer.CustomerDetails;
import com.app.customer.ServicePlans;

import exceptions.CustomerException;

public class CustomerValidations {

	private static final Pattern EMAIL_PATTERN = Pattern.compile("^[a-zA-Z0-9_]+@[a-zA-Z0-9.-]+\\.(com|org|net)$");

	private static final Pattern PASSWORD = Pattern.compile("^[0-9A-Za-z]{6,16}$");

	public static CustomerDetails validateCust(String fname, String lname, String email, String password,
			double regamount, String dob, String scPlan, List<CustomerDetails> cstList) throws CustomerException {

		ServicePlans pla = validatePlan(scPlan);
		validateregAmount(pla, regamount);
		validateEmail(email);
	validatePassword(password);

		int index = -1;
		for (CustomerDetails d1 : cstList) {
			if (d1.getEmail().contains(email)) {
				// throw new excep
				System.out.println("Already customer exists");
			}
			// System.out.println(index);
		}

		return new CustomerDetails(fname, lname, email, password, regamount, LocalDate.parse(dob), pla);

	}

	public static CustomerDetails validateSignIn(String email, String password, List<CustomerDetails> cstList)
			throws CustomerException {

		int index = -1;
		for (CustomerDetails d1 : cstList) {
			if (d1.getEmail().equals(email) && d1.getPassword().equals(password)) {
				index = cstList.indexOf(d1);
				break;
			}
			// System.out.println(index);
		}

		if (index == -1)
			throw new CustomerException("Incorrect email or password");
		else
			System.out.println("You've Signed in");
		return cstList.get(index);

	}

	public static void changePassword(String email, String opass, String npass, List<CustomerDetails> cstList)
			throws CustomerException {

		for (CustomerDetails d1 : cstList) {
			if (d1.getEmail().equals(email) && d1.getPassword().equals(opass)) {
				d1.setPassword(npass);
				System.out.println("Updated Password");
				break;
			} else {
				throw new CustomerException("Customer not found Incorrect email or password");
			}

		}

		return;

	}

	public static String validateSubs(String email, String password, List<CustomerDetails> cstList)
			throws CustomerException {
		boolean flag = false;
		for (CustomerDetails d2 : cstList) {
			if (d2.getEmail().equals(email) && d2.getPassword().equals(password)) {
				d2.setSubscription(false);
				System.out.println("Unsubscribed success");
				flag = true;
			}
		}
		if (!flag) {
			throw new CustomerException("Unsuccess ");
		}

		return null;

	}

	public static ServicePlans validatePlan(String plan) throws CustomerException {
		for (ServicePlans sp : ServicePlans.values()) {
			if (sp.name().equalsIgnoreCase(plan)) {
				System.out.println("Supported plan");
				return ServicePlans.valueOf(plan.toUpperCase());
			}

		}
		// throw new excep
		throw new CustomerException("Unsupported plan");

	}

	public static void validateregAmount(ServicePlans plan, double regAmount) throws CustomerException

	{
		if (regAmount < plan.getMinAmount()) {
			throw new CustomerException("Insufficient amount");
		}

	}

	public static void validateEmail(String Email) throws CustomerException {
		boolean isTrue = EMAIL_PATTERN.matcher(Email).matches();
		if (isTrue) {
			return;
		} else {
			throw new CustomerException("Please enter valid email");
		}
	}

	public static void validatePassword(String Password) throws CustomerException {
		boolean isTrue = PASSWORD.matcher(Password).matches();
		if (isTrue) {
			return;
		} else {
			throw new CustomerException("Please enter valid password");
		}
	}
}
