package utils;

import java.util.ArrayList;
import java.util.List;
import static java.time.LocalDate.parse;
import com.app.customer.CustomerDetails;
import static com.app.customer.ServicePlans.*;

public class CustomerUtils {

	public static List<CustomerDetails> populateList(){
		List<CustomerDetails> cust = new ArrayList<>();//up casting
		cust.add(new CustomerDetails("Mrunal","Dhadge","md@gmail.com","md5",4000
				,parse("2001-01-01"),GOLD));
		cust.add(new CustomerDetails("Shreya","Mote","sm@gmail.com","shreya3",8000
				,parse("2001-08-03"),SILVER));
		cust.add(new CustomerDetails("Shraddha","Sb","sb@gmail.com","Sb20",5000
				,parse("2000-07-20"),DIAMOND));
		cust.add(new CustomerDetails("Kirti","Japtap","kjm@gmail.com","kj15",5500
				,parse("2002-01-01"),PLATINUM));
		
		return cust;
		
			
		}
}
