package com.app.customer;


import static java.time.LocalDate.parse;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;



public class CustomerDetails {
	
	private int custId;
	private static int counter;
	static {
		counter=0;
	}
	
	private String fName;
	private String lName;
	private String email;
	private String password;
	private double registrationAmount;
	private LocalDate dob;
	private LocalDate creationDate;
	private ServicePlans scPlan;
	private boolean subscription=true;
	

	public CustomerDetails(String fName, String lName, String email, String password,
			double registrationAmount,LocalDate dob, ServicePlans scPlan) {
		super();
		this.custId = counter++;
		this.fName = fName;
		this.lName = lName;
		this.email = email;
		this.password = password;
		this.dob = dob;
		this.scPlan=scPlan;
//		this.creationDate = LocalDate.now();
		this.registrationAmount = registrationAmount;
		
	}


	


	public String getfName() {
		return fName;
	}


	public void setfName(String fName) {
		this.fName = fName;
	}


	public String getlName() {
		return lName;
	}


	public void setlName(String lName) {
		this.lName = lName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public double getRegistrationAmount() {
		return registrationAmount;
	}


	public void setRegistrationAmount(double registrationAmount) {
		this.registrationAmount = registrationAmount;
	}


	public LocalDate getDob() {
		return dob;
	}


	public void setDob(LocalDate dob) {
		this.dob = dob;
	}


	public ServicePlans getScPlan() {
		return scPlan;
	}


	public void setScPlan(ServicePlans scPlan) {
		this.scPlan = scPlan;
	}


	@Override
	public String toString() {
		return "CustomerDetails [custId=" + custId + ", fName=" + fName + ", lName=" + lName + ", email=" + email
				+ ", password=" + password + ", registrationAmount=" + registrationAmount + ", dob=" + dob
				+ ", creationDate=" + creationDate + ", scPlan=" + scPlan + "]";
	}





	public boolean isSubscription() {
		return subscription;
	}





	public void setSubscription(boolean subscription) {
		this.subscription = subscription;
	}
	
	
}
