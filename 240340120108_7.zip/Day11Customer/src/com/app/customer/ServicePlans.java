package com.app.customer;

public enum ServicePlans {
	SILVER(1000),GOLD(2000),DIAMOND(5000),PLATINUM(10000);

	private double minAmount;

	private ServicePlans(double minAmount) {
		this.minAmount = minAmount;
	}

	public String toString() {
		return name()+":"+minAmount;
	}
	public double getMinAmount() {
		return minAmount;
	}

	public void setMinAmount(double minAmount) {
		this.minAmount = minAmount;
	}
	
}
