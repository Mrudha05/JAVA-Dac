package exceptions;

public class CustomerException extends Exception{

	public CustomerException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	
}
