package tester;

import java.time.LocalDate;

import java.util.List;
import java.util.Scanner;

import com.app.customer.CustomerDetails;

import static utils.CustomerUtils.*;
import static utils.CustomerValidations.validateCust;
import static utils.CustomerValidations.validateSignIn;
import static utils.CustomerValidations.changePassword;
import static utils.CustomerValidations.validateSubs;

public class CustomerManagementSystem {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			List<CustomerDetails> cstList = populateList();
			boolean exit = false;
			while (!exit) {
				System.out.println("Options\n" + "1.Sign up\n" + "2.Sign in\n" + "3.Change Password\n"
						+ "4.Unsubscribe Customer\n" + "5.Display All Customers\n"+"0.Exit\n" + "Select your choice");
				try {
					switch (sc.nextInt()) {
					case 1:
						System.out.println("Enter the Details");
						CustomerDetails cd = validateCust(sc.next(), sc.next(), sc.next(), sc.next(), sc.nextDouble(),
								sc.next(), sc.next(), cstList);
						cstList.add(cd);
						System.out.println("Customer Signed Up");
						break;
					case 2:
						System.out.println("Enter the email and password ");
						System.out.println(validateSignIn(sc.next(), sc.next(), cstList));

						break;
					case 3:
						System.out.println("Enter email,old password , new password");
						changePassword(sc.next(), sc.next(), sc.next(), cstList);
						break;
					case 4:
						System.out.println("Unsubscribe enter email");
						validateSubs(sc.next(), sc.next(), cstList);
						break;

					case 5:
						System.out.println("registered Customer Details");
						for (CustomerDetails d : cstList) {
							System.out.println(d);
						}
						break;

					case 0:
						exit = true;
					}
				} catch (Exception e) {
					System.out.println(e);
					System.out.println("Pls retry ...");
				}

			}

		}

	}
}
