package com.app.fruits;


public class Apple extends Fruit {

	public Apple(String color,double weight,String name,boolean fresh)
	{
		super(color,weight,name,fresh);
		
	}

	public String taste()
	{
		return "Sweet and Sour";
	}
	public String toString()
	{
	 return super.toString();	
	}
	public String jam()
	{
		return("Name :"+super.getName()+"Color :"+super.getColor()+" making jam");
	
	}
}
