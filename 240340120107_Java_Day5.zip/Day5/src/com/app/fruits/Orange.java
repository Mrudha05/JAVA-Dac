package com.app.fruits;

public class Orange extends Fruit {

	public Orange(String color, double weight, String name,boolean fresh) {
		super(color, weight, name,fresh);
		// TODO Auto-generated constructor stub
	}
	
	public String taste()
	{
		return "Sour";
	}
	public String toString()
	{
		return super.toString();
	}
	public String juice()
	{
		return("Name :"+super.getName()+"Color :"+super.getColor()+" extracting juice");
	
	}

}
