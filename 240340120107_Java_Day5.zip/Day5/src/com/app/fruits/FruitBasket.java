package com.app.fruits;
import java.util.Scanner;
import com.app.fruits.*;

public class FruitBasket {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the basket size");
		int size=sc.nextInt();
		Fruit[] basket=new Fruit[size];
		int counter=0;
		int s;
		boolean exit=false;
		while(!exit)
		{
			System.out.println("OPTIONS\n"+"1.Add Mango\n"+"2.Add Orange\n"+"3.Add Apple\n"+"4.Display all names of fruits in basket\n"+"5.Display all the details of fruits\n"+"6.Mark fruit as stale\n"+"7.Mark all sour fruits stale\n"+"8.Invoking fruit functionality\n"+"9.Exit\n"+"Enter your choice\n ");
			switch(sc.nextInt())
			{
			case 1:
					if(counter < basket.length) {
					System.out.println("Enter weight");
					s=sc.nextInt();	
					basket[counter]=new Mango("Yelllow" ,s,"Mango",true);
					counter++;
					System.out.println("Mango added");
					}else{
				System.out.println("Basket is Full");}
					break;
			case 2:
					if(counter<basket.length)
					{	
					System.out.println("Enter weight");
					s=sc.nextInt();
					basket[counter]=new Orange("orange" ,s,"Orange",true);
					counter++;
					System.out.println("Orange added");
					}
					else
					System.out.println("Basket is full");	
					break;
			case 3:
					if(counter<basket.length)
					{	
					System.out.println("Enter weight");
					s=sc.nextInt();
					basket[counter]=new Apple("red" ,s,"Apple",true);
					counter++;
					System.out.println("Apple added");
					}
					else 
					System.out.println("Basket is full");	
					
					break;
			case 4:
					System.out.println("Fruits in the basket are:");
					for(int i=0;i<basket.length;i++)
					{
						System.out.println(basket[i].getName());
					}
					break;
			case 5:
				    System.out.println("Fruits in the basket are:");
				    for(int i=0;i<basket.length;i++)
				    {
					System.out.println(basket[i].getName()+" "+basket[i].getColor()+" "+basket[i].getWeight()+" "+basket[i].taste()+" "+basket[i].isFresh()+"\n");
				    }
				    break;
			case 6:
					System.out.println("Which fruit is stale");
					int st=sc.nextInt()-1;
					if(st>=0 && st<basket.length) {
						basket[st].setFresh(false);
						System.out.println("Marked Stale");
					}
					else
						System.out.println("This fruit is not present in the basket");
					break;
			case 7:
					System.out.println("All sour fruits are marked as stale");
					for(int i=0;i<basket.length;i++)
					{
						if(basket[i].taste().equals("Sour")) {
							basket[i].setFresh(false);
							
						}
						System.out.println("Done");
						
					}
					break;
			case 8:
					System.out.println("Enter the fruit index");
					int fi = sc.nextInt();
					if(fi>=0 && fi<basket.length) {
						Fruit f = basket[fi];
						
						if(f instanceof Mango)
							System.out.println(((Mango) f).pulp());
						else if(f instanceof Apple)
							System.out.println(((Apple)f).jam());
						else
							System.out.println(((Orange)f).juice());
						
						
					}
					break;
					
			case 9: exit=true;
					break;
					
			}
			
		}
		
	}

}
