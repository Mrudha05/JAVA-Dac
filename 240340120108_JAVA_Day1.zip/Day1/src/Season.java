//objective 8

import java.util.Scanner;
class Employee
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int empId=sc.nextInt();
		double salary=sc.nextDouble();
		String fName=sc.next();
		boolean isP=true;
		System.out.printf("employee id is"+empId);
		System.out.printf("employee salaryis"+salary);
		System.out.printf("employee name is"+fName);
		System.out.printf("employee is permanent or not"+isP);
			
		}
			sc.close();
	 }
}


		
	