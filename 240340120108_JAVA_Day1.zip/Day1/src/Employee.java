//objective 8

import java.util.Scanner;
class Employee
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the employee details");
		System.out.println("Enter the employee id");

		int empId=sc.nextInt();
		System.out.println("Enter the employee salary");

		double salary=sc.nextDouble();
		System.out.println("Enter the employee name");

		String fName=sc.next();
		System.out.println("Is employee permanent?");

		boolean isP= sc.nextBoolean();
		System.out.printf("employee id is"+empId);
		System.out.printf("employee salaryis"+salary);
		System.out.printf("employee name is"+fName);
		System.out.printf("employee is permanent"+isP);
			
	
			sc.close();
	 }
}


		
	