//objective 6

import java.util.Scanner;
class Odd
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter begin and end values");
		int b=sc.nextInt();
		int e=sc.nextInt();
		for(int i=b;i<=e;i++)
		{
			if(isOdd(i))
			System.out.println(i+" ");
		}
		System.out.println("Sum = "+ (n1+n2));
	}
	public static boolean isOdd(int no)
	{
		if(no%2!=0)
		return true;
		return false;
	}
}