//Assignment 4.1

import java.util.Scanner;
class Average
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter double values");
		if(sc.hasNextDouble())
		{
		double d1=sc.nextDouble();
		double d2=sc.nextDouble();
		System.out.println("Average = "+(d1+d2/2));
		}
		else
		{
		System.out.println("Error!,Please enter double values");
		}
		
		sc.close();
	}
}