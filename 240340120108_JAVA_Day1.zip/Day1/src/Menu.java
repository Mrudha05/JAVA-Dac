//Assignment 4.2

import java.util.Scanner;
class Menu
{
public static void main(String[] args)
	{

	System.out.println("      MENU       ");
	System.out.println("1.Dosa..........30");
	System.out.println("2.Idli..........25");
	System.out.println("3.Samosa........30");
	System.out.println("4.Upama.........20");
	System.out.println("5.Noodles.......50");
        System.out.println("6.Sandwich......45");
	System.out.println("7.Burger........55");
	System.out.println("8.French Fries..60");
	System.out.println("9.Cold Coffee...40");
	System.out.println("Enter your choice");


	Scanner sc=new Scanner(System.in);
	int choice=sc.nextInt();
	int price=0;
	
	while(choice!=10)
	{
	switch(choice)
	{
	case 1: System.out.println("Enter quantity");
		int q=sc.nextInt();
		price=(q*30) +price ;
		break;
	case 2: System.out.println("Enter quantity");
		 q=sc.nextInt();
		price=(q*25) + price;
		break;
	case 3: System.out.println("Enter quantity");
		 q=sc.nextInt();
		price=(q*30)+price;
		break;

	case 4: System.out.println("Enter quantity");
		 q=sc.nextInt();
		price=(q*20)+price;
		break;
	case 5: System.out.println("Enter quantity");
		 q=sc.nextInt();
		price=(q*50)+price;
		break;
	case 6: System.out.println("Enter quantity");
		 q=sc.nextInt();
		price=(q*45)+price;
		break;
	case 7: System.out.println("Enter quantity");
		 q=sc.nextInt();
		price=(q*55)+price;
		break;
	case 8: System.out.println("Enter quantity");
		 q=sc.nextInt();
		price=(q*60)+price;
		break;
	case 9: System.out.println("Enter quantity");
		 q=sc.nextInt();
		price=(q*40)+price;
		break;
	case 10:System.out.println("Bill");
		break;
	}
	System.out.println("Do you want to add more then enter your choice else 10");
	choice=sc.nextInt();
}
System.out.println("Generated Bill = "+price);
}
	}