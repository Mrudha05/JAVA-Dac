//Objective 5

import java.util.Scanner;
class Compare
{
	public static void main(String[] args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Two Numbers");
	int a=sc.nextInt();
	int b=sc.nextInt();
	if(a>b) System.out.println(a+">"+b);
	else if(a<b) System.out.println(a+"<"+b);
	else System.out.println("Both are Equal");
	sc.close();
	}
}