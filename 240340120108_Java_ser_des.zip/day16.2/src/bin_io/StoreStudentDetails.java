package bin_io;

import java.util.Map;
import java.util.Scanner;


import com.app.core.Student;

import static utils.StudentCollectionUtils.populateList;
import static utils.StudentCollectionUtils.populateMap;
import static utils.IOUtils.storeStudentDetails;

public class StoreStudentDetails {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			// get populated map
			Map<String, Student> studentMap = populateMap(populateList());
			System.out.println("Enter file name");
			storeStudentDetails(studentMap, sc.nextLine());
			System.out.println("stored students....");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
