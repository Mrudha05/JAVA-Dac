package utils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;

import com.app.core.Student;

public interface IOUtils {
//add a static method to store student details(map) in bin file using ser.
	static void storeStudentDetails(Map<String, Student> productMap, 
			String fileName) throws IOException {
		// Java App --> OOS --> bin strm --> FOS --> bin file
		try (ObjectOutputStream out = 
				new ObjectOutputStream(new FileOutputStream(fileName))) {
			out.writeObject(productMap);// ser.
		} //JVM : out.close --> fos.close
	}

	
}
