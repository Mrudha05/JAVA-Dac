package tester1;
import static utils.StudentCollectionUtils.*;

import java.util.Comparator;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.stream.DoubleStream;

import com.app.core.*;

public class Test1 {

	public static void main(String[] args) {
	//2.1 Display  student details for specified subject , sorted as per DoB
		
		Map<String,Student> studentMap= populateMap(populateList());
//		Comparator<Student> comp = (p1,p2)-> ((p1.getDob().compareTo(p2.getDob())));
//		//studentMap.forEach((k,v)-> System.out.println(v));
		Subject subject =Subject.DBT;
//		studentMap.values()//Collection<Student>
//		.stream()//Stream<Student> all
//		.filter(p-> p.getSubject()//Stream<Student> Subject specific
//		.equals(subject)).sorted(comp)//Stream<Student> sorted stream
//		.forEach(p->System.out.println(p));
		
		
	//2.2 Print average of  marks of students from the specified state
	
	   //double avg;
//        OptionalDouble avg;
//	    avg=studentMap.values()//Collection<student>
//	     .stream()
//	     .filter(s-> s.getAddress().getState().equals("MH"))//Filtered stream<student>
//	     .mapToDouble(m->m.getGpa()).average();//String->Double 
//	    //.orElseThrow();
//	    
//	    System.out.println(avg);
//	     
	

	// Print name of specified subject  topper
	Comparator<Student> comp1 = (s1,s2)-> ((Double)s1.getGpa()).compareTo(s2.getGpa());
       String name = studentMap.values()
       .stream()
       .filter(p->p.getSubject().equals(subject))
       .max(comp1)
       .orElseThrow().getName();
       
       System.out.println("Name : "+ name);
}
}