package bin_io;


import java.util.Scanner;
import static utils.IOUtils.restoreStudentDetails;

public class RestoreStudents {

	public static void main(String[] args) {
		
			try (Scanner sc = new Scanner(System.in)) {
				System.out.println("Enter file name");
				Object details = restoreStudentDetails(sc.nextLine());
				System.out.println(details.getClass());
				System.out.println(details);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("main over...");

		

	}

}
