package tester;

import java.util.Scanner;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

//import static utils.FuelValidationRules.validateFuel;
import static utils.VehicleValidationRules.validateSpeed;
import static utils.VehicleValidationRules.validateFuel;
import static utils.VehicleValidationRules.validateLicense;
import enums.Fuel;
//import utils.SimpleDateFormat;

public class TestValidateSpeed {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter current speed");
			validateSpeed(sc.nextInt());
			System.out.println("Enter fuel type");
			validateFuel(sc.next());
			//SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd");
			//LocalDate dt;
			System.out.println("Enter License expiry date");
			//Date dob=s.parse(sc.next());	
			validateLicense(sc.next());
			//validateLicense(s.parse(sc.next()));
//			Date d1 =new Date();
//			System.out.println("Current"+d1);
			//validateLicense(sc.next());
			System.out.println("end of try...");
		} // JVM : sc.close() => clean up of the resources :std i/p stream
		catch (Exception e) {
			System.out.println(e);//name + err mesg
		}
		System.out.println("main over....");

	}

	

}
