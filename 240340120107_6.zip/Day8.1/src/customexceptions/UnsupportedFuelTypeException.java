package customexceptions;

public class UnsupportedFuelTypeException  extends Exception{
	public UnsupportedFuelTypeException(String mesg) {
		super(mesg);
	}

}
