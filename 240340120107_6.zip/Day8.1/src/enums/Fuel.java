package enums;

public enum Fuel {

		PETROL,CNG,EV;
		
		@Override
		public String toString()
		{
			return name().toLowerCase();
		}
	}
	

