package com.cdac.stack;

public class GrowableStack  extends FixedStack{
	
	@Override
	public void push(Customer cust) {	
		if(top<cst.length-1)
		{
			cst[++top]=cust;
		}
		else {
			Customer[] temp = new Customer[cst.length*2];
			for(int i=0;i<cst.length;i++)
			{
				temp[i]=cst[i];		
			}
			cst=temp;
			cst[++top]=cust;
		   }
		
	  }
}



