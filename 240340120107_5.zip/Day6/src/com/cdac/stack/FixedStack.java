package com.cdac.stack;

public class FixedStack implements Stack {
	protected int top;
	protected Customer [] cst;
	
	public FixedStack() {
	top=-1;
    cst = new Customer[STACK_SIZE];
	}
	
	@Override
	public void push(Customer cust) {
		if(top<cst.length-1)
		{
	
			cst[++top]=cust;
		}
		else
		{
			System.out.println("stack is full");
		}
		
	}

	@Override
	public Customer pop() {
		if(top==-1)
		{
			System.out.println("Stack is empty");
		}
		else {
			
			return cst[top--];
		}
		
		return null;
	}

	
}
