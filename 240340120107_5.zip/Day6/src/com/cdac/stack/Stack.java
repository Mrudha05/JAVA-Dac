package com.cdac.stack;

public interface Stack {
	int STACK_SIZE=4;
	 
	 void push(Customer cust);

	    Customer pop();
	

}
