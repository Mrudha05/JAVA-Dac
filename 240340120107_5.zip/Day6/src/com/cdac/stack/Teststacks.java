package com.cdac.stack;
import java.util.Scanner;
public class Teststacks {

	public static void main(String[] args) {
		try(Scanner sc=new Scanner(System.in)){
		boolean exit=false;
		Stack ref=null;
		int choice;
		while(!exit)
		{
			
				
			System.out.println("Display Menu\n" +"1.Choose Fixed Stack\n"+"2.Choose Growable Stack\n"+"3.Push Data\n"+"4.Pop Data\n"+"5.Exit\n");
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:if(ref==null)
				   		ref = new FixedStack();
					else
						System.out.println("Stack alredy selected you cannot change now");
					break;
				
			case 2:if(ref==null)
						ref = new GrowableStack();
					else 
						System.out.println("Stack alredy selected you cannot change now");
					break;

			
			case 3:System.out.println("Enter Customer Details:");
			        ref.push(new Customer(sc.nextInt(),sc.next(),sc.next()));
			        break;
				
			case 4:System.out.println("Customer Details :");
				   System.out.println(ref.pop());
				   break;
			
			case 5:exit=true;
			}
		
		}
		

	}
	}

}
