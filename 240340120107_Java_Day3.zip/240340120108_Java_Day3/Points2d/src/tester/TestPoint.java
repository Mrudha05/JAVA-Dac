package tester;
import java.util.Scanner;
public class TestPoint {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("How many points to plot");
		int n=sc.nextInt();
		UI[] points = new UI[n];
		int option;
		
		do {
			System.out.println("1 : Plot a point");
			System.out.println("2 : Display All the points ");
			System.out.println("3 : Exit");
			System.out.println("Enter the option for the menu :");
			option = sc.nextInt();
			switch(option) {
			case 1:
				System.out.println("Enter the index you want to insert :");
				int index =sc.nextInt();
				if(index <0 || points.length <= index) {
					System.out.println("Please enter the valid index ");
				}else {
					if(points[index] == null) {
						System.out.println("Enter X and Y co-ordinates");
						double x = sc.nextDouble();
						double y = sc.nextDouble();
						points[index] = new UI(x,y);
					}else {
						System.out.println("Points already plotted ");
					}
				}
				break;
			case 2:
				for(UI u:points)
				{
					System.out.println(u.Show());
				}
				break;
			case 3: System.out.println("Exited");
			}
			
			
		}while(option!=3);
	}

}
