package tester;

public class UI {
	
	private double x;
	private double y;
	public UI(double x,double y)
	{
		this.x=x;
		this.y=y;
	}
	public String Show()
	{
	return "Co-ordinates of x and y are "+this.x+" "+this.y;
	}
	public double getXvalue() {
		return this.x;
	}
	public double getYvalue() {
		return this.y;
	}
	public void setXvalue(double x) {
		this.x = x;
	}
	public void setYvalue(double y) {
		this.y = y;
	}
	public Boolean isEqual(UI p)
	{
	 if(this.x==p.x && this.y==p.y) return true;
	 return false;


	}
	public Boolean isInserted(double x,double y) {
		if(this.x == x && this.y == y) return true;
		return false;
	}

}
